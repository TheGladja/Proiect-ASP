﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Models.Constants
{
    public class UserRoleType
    {
        public static readonly string Admin = "Admin";
        public static readonly string User = "User";
    }
}
