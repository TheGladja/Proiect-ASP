﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProiectFinalCCI.Entities;
using ProiectFinalCCI.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Data
{
    public class ContextProiect :  IdentityDbContext<User, Role, int,
        IdentityUserClaim<int>, UserRole, IdentityUserLogin<int>,
        IdentityRoleClaim<int>, IdentityUserToken<int>>
    {
        public ContextProiect(DbContextOptions options) : base(options) { }
        public DbSet<Professor>  Professors { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<School> Schools { get; set; }
        public DbSet<ProfessorSchool> ProfessorSchools { get; set; }
        public DbSet<SessionToken> SessionTokens { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //DB

            //One to Many

            modelBuilder.Entity<Professor>()
                .HasMany(p => p.Students)
                .WithOne(s => s.Professor)
                .HasForeignKey(s => s.ProfessorId);

            modelBuilder.Entity<User>()
                .HasOne(u => u.Professor)
                .WithOne(p => p.User);

            modelBuilder.Entity<User>()
                .HasOne(u => u.Student)
                .WithOne(s => s.User);

            //One to One

            modelBuilder.Entity<Professor>()
                .HasOne(p => p.Address)
                .WithOne(a => a.Professor);


            //Many to Many

            modelBuilder.Entity<ProfessorSchool>().HasKey(ps => new{ps.ProfessorId, ps.SchoolId});

            modelBuilder.Entity<ProfessorSchool>()
                .HasOne(ps => ps.Professor)
                .WithMany(p => p.ProfessorSchools)
                .HasForeignKey(ps => ps.ProfessorId);

            modelBuilder.Entity<ProfessorSchool>()
                .HasOne(ps => ps.School)
                .WithMany(s => s.ProfessorSchools)
                .HasForeignKey(ps => ps.SchoolId);

            //Login

            modelBuilder.Entity<UserRole>(ur =>
            {
                ur.HasKey(ur => new { ur.UserId, ur.RoleId });

                ur.HasOne(ur => ur.Role).WithMany(r => r.UserRoles).HasForeignKey(ur => ur.RoleId);
                ur.HasOne(ur => ur.User).WithMany(u => u.UserRoles).HasForeignKey(ur => ur.UserId);
            });

           base.OnModelCreating(modelBuilder);
        }

    }
}
