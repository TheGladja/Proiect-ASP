﻿using ProiectFinalCCI.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Entities.DTO
{
    public class CreateStudentDTO
    {
        public int Id { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public int Avg_Grade { get; set; }
        public int ProfessorId { get; set; }
        public int UserId { get; set; }
        public Professor Professor { get; set; }
        public User User { get; set; }

    }
}
