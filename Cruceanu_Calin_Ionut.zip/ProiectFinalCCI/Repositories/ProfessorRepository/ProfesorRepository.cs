﻿using Microsoft.EntityFrameworkCore;
using ProiectFinalCCI.Data;
using ProiectFinalCCI.Entities;
using ProiectFinalCCI.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Repositories.ProfessorRepository
{
    public class ProfesorRepository : GenericRepository<Professor>, IProfessorRepository
    {
        public ProfesorRepository(ContextProiect context) : base(context) { }

        public async Task<Professor> GetProfessorByName(string last_name)
        {
            return await _context.Professors.Include(p => p.Address).Include(p => p.User).Where(p => p.Last_Name.Equals(last_name)).FirstOrDefaultAsync();
        }

        public async Task<Professor> GetProfessorByIdWithAddressAndRole(int id)
        {
            return await _context.Professors.Include(p => p.Address).Include(p => p.User).Where(p => p.Id == id).FirstOrDefaultAsync();
        }

        public async Task<List<Professor>> GetProfessorsWithAddressAndRole()
        {
            return await _context.Professors.Include(p => p.Address).Include(p => p.User).ToListAsync();
        }
    }
}
