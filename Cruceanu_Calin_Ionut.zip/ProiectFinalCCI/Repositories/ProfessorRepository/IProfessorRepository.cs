﻿using ProiectFinalCCI.Entities;
using ProiectFinalCCI.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Repositories.ProfessorRepository
{
    public interface IProfessorRepository : IGenericRepository<Professor>
    {
        Task<Professor> GetProfessorByName(string last_name);
        Task<Professor> GetProfessorByIdWithAddressAndRole(int id);
        Task<List<Professor>> GetProfessorsWithAddressAndRole();
    }
}
