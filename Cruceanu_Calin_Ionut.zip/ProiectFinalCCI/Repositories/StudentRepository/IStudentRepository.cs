﻿using ProiectFinalCCI.Entities;
using ProiectFinalCCI.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Repositories.StudentRepository
{
    public interface IStudentRepository : IGenericRepository<Student>
    {
        Task<Student> GetStudentByName(string last_name);
        Task<Student> GetStudentByIdWithRole(int id);
        Task<List<Student>> GetStudentWithRoleName();
    }
}
