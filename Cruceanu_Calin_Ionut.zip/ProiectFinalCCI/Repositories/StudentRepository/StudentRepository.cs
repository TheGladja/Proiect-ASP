﻿using Microsoft.EntityFrameworkCore;
using ProiectFinalCCI.Data;
using ProiectFinalCCI.Entities;
using ProiectFinalCCI.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Repositories.StudentRepository
{
    public class StudentRepository : GenericRepository<Student>, IStudentRepository
    {
        public StudentRepository(ContextProiect context) : base(context) { }
        public async Task<Student> GetStudentByIdWithRole(int id)
        {
            return await _context.Students.Include(s => s.User).Include(s => s.User).Where(s => s.Id == id).FirstOrDefaultAsync();
        }

        public async Task<Student> GetStudentByName(string last_name)
        {
            return await _context.Students.Include(s => s.User).Where(s => s.Last_Name.Equals(last_name)).FirstOrDefaultAsync();
        }

        public async Task<List<Student>> GetStudentWithRoleName()
        {
            return await _context.Students.Include(s => s.User).ToListAsync();
        }
    }
}
