﻿using ProiectFinalCCI.Entities;
using ProiectFinalCCI.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Repositories.SchoolRepository
{
    public interface ISchoolRepository : IGenericRepository<School>
    {
        Task<School> GetSchoolWithName(string name);
        Task<School> GetSchoolById(int id);
        Task<List<School>> GetSchools();
    }
}
