﻿using ProiectFinalCCI.Entities;
using ProiectFinalCCI.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectFinalCCI.Repositories.AddressRepository
{
    public interface IAddressRepository : IGenericRepository<Address>
    {
        Task<Address> GetAddressById(int id);
        Task<List<Address>> GetAddresses();
    }
}
